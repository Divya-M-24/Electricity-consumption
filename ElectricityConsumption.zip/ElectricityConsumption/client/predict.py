import lazy_predict

print(lazy_predict.predict_usage('Karnataka',20,4))